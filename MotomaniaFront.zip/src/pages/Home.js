import React from "react";
import Mapa from './../components/Mapa'

export default function Home() {
  return (
    <div>
      <Mapa />

    </div>
  );
}
