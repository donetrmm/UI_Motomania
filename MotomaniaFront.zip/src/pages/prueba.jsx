import React, { useState } from 'react';

export default function prueba(miProp ) {
  
  return (
    <div>
    <p>Valor de la prop recibida: {miProp}</p>
  </div>
  )
}
