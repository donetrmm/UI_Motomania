import React from 'react'

export default function IconMenuAdmin({url,nombre}) {
  return (
    <>
    <img src={url} alt={nombre} height="150px"></img>
    </>
  )
}
