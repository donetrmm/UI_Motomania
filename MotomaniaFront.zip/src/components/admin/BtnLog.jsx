import React from 'react'
import { Button } from '@mui/material'
export default function BtnLog() {
  return (
    <>
    <Button 
    variant="outlined"
    type='submit'
    sx={{m:'20px'}}
    >
        Registrar Usuario 
    </Button>
    </>
  )
}
