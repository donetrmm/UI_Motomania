import React from 'react'
import InputLabel from "@mui/material/InputLabel";
export default function InputLabelAd() {
  return (
    <>
    <InputLabel>
    Productos
    </InputLabel>
    </>
  )
}
