import React from "react";
import { Typography } from "@mui/material";
export default function TextAtributoCards({ atri }) {
  return (
    <>
      <Typography variant="subtitle1">{atri}</Typography>
    </>
  );
}
